#!/bin/bash

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

PORTSDIR="/$directory/ports"
GAMELIST="$PORTSDIR/gamelist.xml"

if [ ! -f "$GAMELIST" ]; then
    echo "ERROR: $GAMELIST not found."
    exit 1
fi

TMP="/tmp/gamelist.pretty.xml"

python3 <<EOF
import xml.dom.minidom as md
import xml.etree.ElementTree as ET

src = "$GAMELIST"
tmp = "/tmp/gamelist.pretty.xml"

def remove_whitespace_nodes(node):
    """Remove minidom whitespace-only text nodes."""
    remove = []
    for child in node.childNodes:
        if child.nodeType == child.TEXT_NODE and child.data.strip() == "":
            remove.append(child)
        elif child.hasChildNodes():
            remove_whitespace_nodes(child)
    for child in remove:
        node.removeChild(child)

try:
    # Load existing XML
    tree = ET.parse(src)
    root = tree.getroot()

    # Convert ET -> pretty DOM
    rough = ET.tostring(root, encoding="utf-8")
    dom = md.parseString(rough)

    # Remove whitespace garbage before pretty-printing
    remove_whitespace_nodes(dom)

    #pretty = md.parseString(rough).toprettyxml(indent="  ")
    pretty = dom.toprettyxml(indent="  ")

    # Write pretty XML
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(pretty)

    print("Wrote:", tmp)

except Exception as e:
    print("ERROR prettifying:", e)
    pm_finish
    exit(1)
EOF

if [ -f "$TMP" ]; then
    cp "$TMP" "$GAMELIST"
    sync
    echo "Updated: $GAMELIST"
    pm_message "$GAMELIST has been prettified!"
    /opt/inttools/text_viewer -f 20 -w -t "$GAMELIST" -m "$GAMELIST has been prettified! \n\nPress 'Select' to exit this Text Viewer"
    sleep 2
    pm_finish
    # shutdown -r now
else
    pm_message "ERROR: Pretty XML not generated."
    sleep 2
    pm_finish
    exit 1
fi
